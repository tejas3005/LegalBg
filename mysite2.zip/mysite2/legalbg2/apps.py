from django.apps import AppConfig


class Legalbg2Config(AppConfig):
    name = 'legalbg2'
