from django.contrib import admin
from legalbg2.models import law
# Register your models here.
admin.site.register(law)
