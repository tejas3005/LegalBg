from django.db import models

# Create your models here.
import uuid
from cassandra.cqlengine import columns
from django_cassandra_engine.models import DjangoCassandraModel

class law(DjangoCassandraModel):
    title = columns.Text(primary_key = True)
    author = columns.Text()
    bench = columns.Text()
    citation = columns.Text()
    detailed_explaination = columns.Text()

    def __str__(self):
        return self.title
